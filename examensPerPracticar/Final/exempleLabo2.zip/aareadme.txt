Feu els tres exercicis:
  opt.pl     (5 punts)
  prolog.pl  (3 punts)
  clp.pl     (2 punts)
Cal entregar TRES arxius AMB AQUESTS NOMS exactes (NO zip ni similars).
